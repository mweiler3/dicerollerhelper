package me.xdrop.jrand.generators.location

class PhoneGeneratorTest {
}
