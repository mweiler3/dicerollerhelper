package me.xdrop.jrand.data

class AssetLoaderTest extends GroovyTestCase {

    void testDontFail() {
        // TODO
    }
}
