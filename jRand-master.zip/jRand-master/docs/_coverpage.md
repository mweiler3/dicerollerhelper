<!-- _coverpage.md -->

![logo](_media/logoonly.svg)

# jrand <small>0.2.6-alpha</small>

> Probably the *best* Java library for random data generation.*

- Simple and lightweight 
- Minimal dependencies
- Tons of generators

[GitHub](https://github.com/xdrop/jrand/)
[Get Started](#jrand)

![](_media/bg.jpg)
