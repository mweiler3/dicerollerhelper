package me.xdrop.jrand.data;

public interface AssetMapper<T> {
    T map(String element);
}
