package me.xdrop.jrand.model.person;

public enum Gender {
    MALE,
    FEMALE,
    NEUTRAL
}
