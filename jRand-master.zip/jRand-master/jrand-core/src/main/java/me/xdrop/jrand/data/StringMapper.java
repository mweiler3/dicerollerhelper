package me.xdrop.jrand.data;

public class StringMapper implements AssetMapper<String> {
    @Override
    public String map(String element) {
        return element;
    }
}
